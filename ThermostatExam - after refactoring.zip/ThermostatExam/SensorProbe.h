#ifndef __SENSOR_PROBE_H__
#define __SENSOR_PROBE_H__

int  SensorProbe_GetTemperature();


#endif // !__SENSOR_PROBE_H__
