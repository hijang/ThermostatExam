#ifndef __TARGET_SPECIFIC_DUMMY_H__
#define __TARGET_SPECIFIC_DUMMY_H__

void  initializeTargetSpecifics();

#endif // !__TARGET_SPECIFIC_DUMMY_H__
