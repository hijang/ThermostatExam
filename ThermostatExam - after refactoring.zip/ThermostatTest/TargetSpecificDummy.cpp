
extern "C"
{	
#include "TargetSpecificDummy.h"
}


void  initializeTargetSpecifics()
{
}

