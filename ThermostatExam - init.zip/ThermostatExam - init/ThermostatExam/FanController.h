#ifndef __FAN_CONTROLLER_H__
#define __FAN_CONTROLLER_H__


void  FanController_SetFanSpeed(unsigned short  speed);


#endif // !__FAN_CONTROLLER_H__
