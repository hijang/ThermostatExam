#ifndef __HEATER_CONTROLLER_H__
#define __HEATER_CONTROLLER_H__

void  HeaterController_TurnOn();
void  HeaterController_TurnOff();

#endif // !__HEATER_CONTROLLER_H__
