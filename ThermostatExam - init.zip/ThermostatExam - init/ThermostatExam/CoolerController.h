#ifndef __COOLER_CONTROLLER_H__
#define __COOLER_CONTROLLER_H__

void  CoolerController_TurnOn();
void  CoolerController_TurnOff();

#endif // !__COOLER_CONTROLLER_H__
