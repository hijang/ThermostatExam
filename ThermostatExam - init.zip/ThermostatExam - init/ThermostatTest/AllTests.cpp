#include "CppUTest\CommandLineTestRunner.h"


int  main(int  argc, char**  argv)
{
	return RUN_ALL_TESTS(argc, argv);
}