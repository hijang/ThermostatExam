#ifndef __FAN_CONTROLLER_SPY_H__
#define __FAN_CONTROLLER_SPY_H__

void  FanControllerSpy_Create();
void  FanControllerSpy_Destroy();

int  FanControllerSpy_GetFanSpeed();


#endif // !__FAN_CONTROLLER_SPY_H__
