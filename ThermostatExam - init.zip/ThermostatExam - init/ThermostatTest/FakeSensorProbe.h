#ifndef __FAKE_SENSOR_PROBE_H__
#define __FAKE_SENSOR_PROBE_H__

void  FakeSensorProbe_Create();
void  FakeSensorProbe_Destroy();
void  FakeSensorProbe_SetTemperature(int  temperature);


#endif // !__FAKE_SENSOR_PROBE_H__
